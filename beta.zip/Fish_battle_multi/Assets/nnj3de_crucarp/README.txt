Cartoon crucian carp

490 tris
1024x512 texture
swim animation